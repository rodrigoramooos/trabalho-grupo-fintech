# 🌐 Ecossistema e Casos de Uso NEAR

> **Tags:** `#ecossistema` `#Aurora` `#DeFi` `#RWA` `#pagamentos` `#identidade`

---

## Camadas do Ecossistema

```
┌─────────────────────────────────────────────────┐
│              APLICAÇÕES (dApps)                  │
│     DeFi · NFTs · Identidade · RWA · Pagamentos  │
├───────────────────┬─────────────────────────────┤
│   AURORA (EVM)    │    NEAR PROTOCOL (L1)        │
├───────────────────┴─────────────────────────────┤
│           RAINBOW BRIDGE                         │
│        NEAR ↔ Ethereum                           │
└─────────────────────────────────────────────────┘
```

---

## Aurora — EVM sobre NEAR

- EVM implementada como smart contract na NEAR
- Executa contratos Solidity sem modificações
- Compatível com MetaMask, Hardhat, Ethers.js
- Custo: ~$0,02 vs. $3–50 no Ethereum L1

---

## Rainbow Bridge

- Ponte trustless NEAR ↔ Ethereum via light clients bidirecionais
- NEAR → ETH: ~4 horas | ETH → NEAR: ~2 minutos
- Suporta: ERC-20, ERC-721 (NFTs), ETH nativo

---

## DeFi no Ecossistema NEAR

### Projetos de Referência

| Projeto | Categoria | Nota de análise |
|---|---|---|
| Ref Finance | DEX (AMM) | [[Skills/s7-casos-estudo-projectos-reais#Ref Finance\|Ver caso de estudo]] |
| Meta Pool | Liquid Staking (stNEAR) | [[Skills/s7-casos-estudo-projectos-reais#Meta Pool\|Ver caso de estudo]] |
| Sweat Economy | Move-to-Earn | [[Skills/s7-casos-estudo-projectos-reais#Sweat Economy\|Ver caso de estudo]] |
| NEAR Social | Rede Social On-Chain | [[Skills/s7-casos-estudo-projectos-reais#NEAR Social\|Ver caso de estudo]] |

---

## Identidade Digital

- Contas com nomes legíveis: `alice.near`, `empresa.near`
- Estrutura hierárquica: `subdominio.conta.near`
- **Multiple keys:** Full Access Key + Function Call Keys com permissões diferenciadas
- **Recovery keys:** recuperação de conta sem seed phrase exposta
- Potencial integração com **DID (W3C)** para KYC portátil → [[Skills/s8-web3-descentralizacao-futuro#SSI|SSI/DID]]

---

## Tokenização de Ativos Reais (RWA)

| Ativo | Estado |
|---|---|
| Imóveis | Emergente — projetos piloto |
| Obrigações / dívida pública | Crescente — interesse institucional |
| Créditos de carbono | Ativo — mercados voluntários |
| Commodities (ouro) | Estabelecido (ex: PAXG) |
| Faturas comerciais | Experimental |

---

## Pagamentos

| Solução | Liquidação | Custo |
|---|---|---|
| NEAR Protocol | ~2 seg | ~$0,001 |
| SEPA Instant | ~10 seg | ~€0,20 |
| Visa/Mastercard | T+1/T+2 | 1,5–3% |
| Bitcoin L1 | ~60 min | $1–50 |

---

## NEAR BOS
- Componentes de UI armazenados on-chain — front-ends resistentes à censura
- Composabilidade: um componente reutilizável entre múltiplas aplicações
- Resposta ao bloqueio do Tornado Cash front-end (OFAC, 2022)

---

## Relações

- → [[Skills/s4-ecossistema-fintech|s4]] (skill associada)
- → [[Skills/s7-casos-estudo-projectos-reais|s7]] para análise crítica de projetos
- → [[Skills/s3-governanca-regulacao|s3]] para implicações regulatórias (MiCA, KYC/AML)
