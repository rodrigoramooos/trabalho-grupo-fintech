# ⚙️ Nightshade Sharding

> **Tags:** `#arquitetura` `#Nightshade` `#sharding` `#consenso` `#seguranca`
> **Fonte:** Skidanov & Polosukhin (2019) — Nightshade Paper

---

## Conceito Central

O Nightshade trata a blockchain NEAR como **uma única cadeia lógica** cujos blocos são fisicamente compostos por *chunks* — partes de bloco produzidas em paralelo por grupos distintos de validadores em cada shard.

---

## Sharding Dinâmico

- Estado da blockchain dividido em **shards** processados em paralelo
- Número de shards ajustável dinamicamente conforme a carga da rede
- Cada shard tem o seu grupo de **chunk producers** responsáveis pela produção e validação dos respetivos chunks
- Um **block producer** agrega os chunks de todos os shards num bloco completo

---

## Doomslug — Algoritmo de Consenso

```
Rodada 1: Block producer propõe bloco
Rodada 2: Validadores emitem endorsements
Resultado: Bloco com >2/3 endorsements = FINAL (irreversível)
```

- Finalidade determinística em **~2 segundos**
- Sem bifurcações longas (*forks*)
- Diferença face ao Ethereum: finalidade probabilística vs. determinística

---

## Segurança

### Hidden Validators
**Problema:** Em sharding, um atacante com <33% do stake total poderia comprometer um shard individual se soubesse antecipadamente quem o valida.

**Solução:** VRF (Verifiable Random Function) seleciona validadores de forma **aleatória e verificável**, revelando apenas no último momento quem valida cada shard.

### Fishermen
- Nós leves que monitorizam a rede
- Submetem **fraud proofs** quando detetam chunks inválidos
- Requerem apenas stake mínimo reduzido — baixa barreira de entrada

### Slashing Progressivo

| Infração | Penalização |
|---|---|
| Double signing | 3× o stake do validador |
| Chunk inválido | 100% do stake do validador |

---

## Comunicação Cross-Shard

- Transações que envolvem múltiplos shards executam-se via **receipts assíncronos**
- Se um chunk for inválido, o sistema executa **rollback** automático dos receipts dependentes
- Sem bloqueio síncrono — preserva o throughput do sistema

---

## Roadmap de Sharding

| Fase | Estado |
|---|---|
| Nightshade 1.0 | Lançado (mainnet 2020) |
| Nightshade 2.0 | Chunk-only producers |
| Nightshade 3.0 | State sync melhorado |
| Nightshade 4.0 | Sharding completo (em desenvolvimento) |

> ⚠️ O TPS real atual (~1–2k) é muito inferior ao potencial teórico (100k+) porque o sharding completo ainda não está ativado.

---

## Relações

- → [[Skills/s2-arquitetura-tecnica|s2 — Arquitetura Técnica]] (skill associada)
- → [[Skills/s5-comparacao-blockchains|s5]] para comparação com Ethereum sharding e Solana PoH
- → [[Agentes/near-protocol-agent|near-protocol-agent]] (agente associado)
