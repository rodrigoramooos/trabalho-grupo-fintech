# 💰 Tokenomics NEAR

> **Tags:** `#tokenomics` `#economia` `#staking` `#inflacao` `#DeFi`
> **Fonte:** NEAR White Paper (NEAR Foundation, s.d.)

---

## Funções do Token NEAR

```
Token NEAR
    ├── Pagamento → gas + armazenamento on-chain
    ├── Staking   → participação no consenso (Thresholded PoS)
    └── Governança → participação em decisões de protocolo
```

---

## Política Monetária

| Parâmetro | Valor | Nota |
|---|---|---|
| Inflação anual máxima | 5% | Distribuída por stakers e treasury |
| Fee burning | 70% das taxas | Pressão deflacionária |
| Protocol Treasury | 0,5% da inflação | Desenvolvimento do ecossistema |
| Contract Rewards | 30% das taxas | Para o developer do contrato |

### Deflação
> Quando o fee burning (70% das taxas) supera a emissão de novos tokens → token torna-se deflacionário

---

## Thresholded Proof-of-Stake

- Limiar mínimo de stake calculado **dinamicamente** por cada epoch (~12 horas)
- Fórmula: `stake_total / max_validators` → validadores acima do limiar entram no conjunto ativo
- Objetivo: maximizar o número de validadores únicos → maior descentralização

### Recompensas de Staking
- ~4,5% anual (aproximado) para stakers ativos
- Distribuídas por epoch
- Liquid staking via [[Skills/s4-ecossistema-fintech#Meta Pool|Meta Pool]] → stNEAR

---

## Modelo de Custos

### Gas
- Unidade de medida do custo computacional
- Calculado algoritmicamente em função da complexidade da operação
- Ajuste dinâmico: se ocupação > 50%, preço sobe; se < 50%, desce
- 1 TGas ≈ 0,0001 NEAR; máximo 300 TGas por transação

### Armazenamento
- **1 NEAR por 100 KB** de dados persistidos on-chain
- O **contrato** paga pelo storage que usa (não o utilizador por defeito)
- Contrato deve manter saldo suficiente — risco de eliminação se saldo insuficiente
- NEP-145 permite ao contrato cobrar aos utilizadores pelo seu próprio storage

---

## Contract Rewards
- 30% das taxas geradas pela utilização de um contrato revertem para o developer desse contrato
- Modelo de negócio direto: developer não precisa de emitir tokens próprios
- Inovação única da NEAR — sem equivalente direto no Ethereum

---

## Comparação Tokenomics

| Parâmetro | NEAR | Ethereum | Solana | Bitcoin |
|---|---|---|---|---|
| Supply máximo | Sem limite | Sem limite | Sem limite | 21M BTC |
| Inflação atual | ≤5% (com queima) | ~0–0,5% | ~5–8% | ~1,7% |
| Fee burning | Sim (70%) | Sim (base fee) | Parcial (50%) | Não |
| Recompensas staking | ~4,5% | ~3,5–4% | ~6–7% | N/A (PoW) |
| Developer rewards | Sim (30%) | Não | Não | N/A |

---

## Relações

- → [[Skills/s1-tokenomics-mercado|s1 — Tokenomics e Mercado]] (skill associada)
- → [[Arquitetura/nightshade#Thresholded PoS|Nightshade — PoS]] para mecanismo de seleção de validadores
- → [[Agentes/near-protocol-agent|near-protocol-agent]] (agente associado)
