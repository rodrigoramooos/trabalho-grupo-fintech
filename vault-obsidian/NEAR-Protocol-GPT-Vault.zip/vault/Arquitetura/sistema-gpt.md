# 🏗️ Sistema NEAR Protocol GPT

> **Tags:** `#arquitetura` `#sistema` `#agentes` `#skills`

---

## Visão Geral

Sistema de agentes de inteligência artificial especializado na blockchain NEAR Protocol, construído sobre a plataforma Claude da Anthropic. Desenvolvido em duas entregas para a UC de FinTech 2025/2026.

---

## Diagrama de Arquitetura

```
                    UTILIZADOR
                        │
           ┌────────────┴────────────┐
           ▼                         ▼
  [[near-protocol-agent]]   [[near-fintech-agent]]
   Arquitetura · Tokenomics   Ecossistema · Regulação
                               Casos de Uso · Web3
           │                         │
    ┌──────┴──────┐          ┌───────┴───────────────┐
    ▼             ▼          ▼    ▼    ▼    ▼    ▼   ▼
   [s1]          [s2]       [s3] [s4] [s5] [s6] [s7] [s8]
   
                    ↕ avalia criticamente ↕
                   [[near-critic-agent]]
```

---

## Componentes

| Componente | Tipo | Âmbito |
|---|---|---|
| [[Agentes/near-protocol-agent\|near-protocol-agent]] | Agente Global | Arquitetura, tokenomics, consenso |
| [[Agentes/near-fintech-agent\|near-fintech-agent]] | Agente Especializado | Ecossistema, regulação, Web3 |
| [[Agentes/near-critic-agent\|near-critic-agent]] | Agente Crítico | Autoavaliação do sistema |
| [[Skills/s1-tokenomics-mercado\|s1]] | Skill | Tokenomics e mercado |
| [[Skills/s2-arquitetura-tecnica\|s2]] | Skill | Arquitetura técnica interna |
| [[Skills/s3-governanca-regulacao\|s3]] | Skill | Governança e regulação |
| [[Skills/s4-ecossistema-fintech\|s4]] | Skill | Ecossistema e FinTech |
| [[Skills/s5-comparacao-blockchains\|s5]] | Skill | Comparação de blockchains |
| [[Skills/s6-desenvolvimento-smart-contracts\|s6]] | Skill | Desenvolvimento de contratos |
| [[Skills/s7-casos-estudo-projectos-reais\|s7]] | Skill | Casos de estudo reais |
| [[Skills/s8-web3-descentralizacao-futuro\|s8]] | Skill | Web3 e futuro |

---

## Princípios de Design

1. **Separação de responsabilidades** — cada componente tem âmbito bem definido sem sobreposição
2. **Rigor académico** — respostas fundamentadas em fontes primárias
3. **Utilidade pedagógica** — conceitos definidos antes de aplicados
4. **Responsabilidade informativa** — separação explícita entre análise e conselho financeiro/jurídico
5. **Equilíbrio analítico** — perspetivas múltiplas; casos de falha documentados

---

## Entregas

| Entrega | Componentes |
|---|---|
| 1ª Entrega | near-protocol-agent · s1 · s2 |
| 2ª Entrega | near-fintech-agent · near-critic-agent · s3 · s4 · s5 · s6 · s7 · s8 |

---

## Materiais Complementares

- [[Recursos/materiais-complementares|Slides · Vídeo · Podcast]]
- Base de conhecimento Obsidian (este vault)
- Relatório Final (Word/PDF)
