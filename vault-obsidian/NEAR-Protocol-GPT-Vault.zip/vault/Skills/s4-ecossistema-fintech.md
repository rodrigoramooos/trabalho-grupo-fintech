# 🧩 s4 — Ecossistema e Casos de Uso FinTech

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#ecossistema` `#DeFi` `#Aurora` `#RWA` `#pagamentos`

---

## Âmbito de Ativação

Ativada quando a questão envolve: Aurora EVM, Rainbow Bridge, DeFi em NEAR, DEX, lending, yield farming, stablecoins, NFTs, identidade digital (nome.near, DID), RWA, pagamentos em blockchain, NEAR como infraestrutura FinTech, NEAR BOS, dApps.

---

## Conteúdo Principal

### Aurora — EVM sobre NEAR
- EVM implementada como smart contract na NEAR → execução de contratos Solidity sem modificações
- Custo ~$0,02 vs. $3–50 no Ethereum L1
- Compatibilidade total com MetaMask, Hardhat, Ethers.js

### Rainbow Bridge
- Ponte bidirecional trustless NEAR ↔ Ethereum (light clients bidirecionais)
- NEAR → Ethereum: ~4 horas | Ethereum → NEAR: ~2 minutos
- Sem federação centralizada de relayers

### DeFi no Ecossistema NEAR

| Categoria | Mecanismo | Exemplo |
|---|---|---|
| DEX | AMM (Automated Market Maker) | Ref Finance |
| Liquid Staking | stNEAR como representação líquida | Meta Pool |
| Lending | Taxas algorítmicas por oferta/procura | — |

### Tokenização de Ativos Reais (RWA)
Imóveis · Obrigações · Créditos de carbono · Commodities · Faturas comerciais

### Pagamentos NEAR vs. Alternativas

| Solução | Liquidação | Custo |
|---|---|---|
| NEAR Protocol | ~2 seg | ~$0,001 |
| SEPA Instant | ~10 seg | ~€0,20 |
| Visa/Mastercard | T+1/T+2 | 1,5–3% |

---

## Relações

- → [[Skills/s3-governanca-regulacao|s3]] para implicações regulatórias dos casos de uso
- → [[Skills/s7-casos-estudo-projectos-reais|s7]] para análise crítica de projetos concretos
- → [[Arquitetura/ecossistema|Ecossistema NEAR]] (nota de arquitetura)

---

## Limitações

- Não constitui recomendação de uso de nenhum protocolo DeFi
- Métricas de TVL e adoção são dinâmicas