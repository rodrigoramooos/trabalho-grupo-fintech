# 🧩 s2 — Arquitetura Técnica

> **Agente:** [[Agentes/near-protocol-agent|near-protocol-agent]]
> **Tags:** `#skill` `#arquitetura` `#Nightshade` `#consenso` `#WASM`

---

## Âmbito de Ativação

Ativada quando a questão envolve: Nightshade sharding, Doomslug, WebAssembly, chunk producers, block producers, epoch, shard, consenso, escalabilidade, throughput, smart contracts, validadores ocultos, Fishermen, slashing, fraud proofs, transações cross-shard, receipts, resharding, VRF.

---

## Conteúdo Principal

### Nightshade Sharding
- Blockchain única lógica dividida em **shards** processados em paralelo
- Cada bloco composto por **chunks** produzidos por grupos distintos de validadores
- Sharding dinâmico: número de shards ajustável conforme a carga

### Doomslug — Algoritmo de Consenso
- Finalidade determinística em **~2 segundos**
- Combinação de heaviest chain + finality gadget por endorsements
- Bloco com endorsement de >2/3 dos validadores = final (irreversível)

### Segurança

| Mecanismo | Função |
|---|---|
| Hidden Validators + VRF | Seleção aleatória e verificável de validadores por shard — impede ataques adaptativos |
| Fishermen | Nós leves que submetem fraud proofs de chunks inválidos |
| Slashing progressivo | Double signing: 3× stake; chunk inválido: 100% stake |

### Runtime WebAssembly (WASM)
- Contratos compilados para WASM a partir de **Rust** (produção) ou **AssemblyScript** (prototipagem)
- Comunicação cross-shard por **receipts assíncronos** com rollback em caso de chunk inválido

---

## Relações

- → [[Arquitetura/nightshade|Nightshade Sharding]] (nota de arquitetura detalhada)
- → [[Skills/s6-desenvolvimento-smart-contracts|s6]] para desenvolvimento prático de contratos
- → [[Agentes/near-protocol-agent|near-protocol-agent]] (agente pai)

---

## Limitações

- Não cobre ecossistema (Aurora, DeFi) → [[Skills/s1-tokenomics-mercado|s1]]
- Não cobre regulação → [[Skills/s3-governanca-regulacao|s3]]
- Baseado no Nightshade Paper (2019) — versões mais recentes podem diferir
