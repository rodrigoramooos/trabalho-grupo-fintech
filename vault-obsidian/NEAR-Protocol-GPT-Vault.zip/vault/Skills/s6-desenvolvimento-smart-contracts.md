# 🧩 s6 — Desenvolvimento de Smart Contracts

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#contratos` `#Rust` `#NEP` `#seguranca` `#dev`

---

## Âmbito de Ativação

Ativada quando a questão envolve: Rust/AssemblyScript para NEAR, NEAR SDK, NEAR CLI, deploy de contratos, NEP-141/171/145, segurança de contratos, storage, gas, cross-contract calls, Promises, upgradeability, near-workspaces.

---

## Conteúdo Principal

### Linguagens
| Linguagem | Uso | SDK |
|---|---|---|
| **Rust** | Produção (recomendado) | near-sdk-rs |
| **AssemblyScript** | Prototipagem | near-sdk-as (descontinuado) |

### Standards NEP

| Standard | Equivalente ETH | Função |
|---|---|---|
| NEP-141 | ERC-20 | Fungible Token |
| NEP-171 | ERC-721 | Non-Fungible Token |
| NEP-145 | — | Storage Management |

### Custos
- **Gas:** ~0,5 TGas (transferência simples) a ~50 TGas (cross-contract call)
- **Armazenamento:** 1 NEAR por 100 KB — contrato paga pelo storage que usa

### Segurança — Vulnerabilidades Críticas

| Vulnerabilidade | Mitigação |
|---|---|
| Re-entrância | Atualizar estado ANTES de transferências externas |
| Overflow aritmético | Usar `checked_add`, `checked_sub` |
| Acesso não autorizado | Verificar `env::predecessor_account_id()` |
| Spam de storage | Implementar NEP-145 |
| Callbacks expostos | Decorator `#[private]` obrigatório |

### Ferramentas
- `near-cli` — deploy, chamada de métodos, gestão de contas
- `near-workspaces` — testes de integração com sandbox local
- Redes: Mainnet · Testnet · Sandbox (local)

---

## Relações

- → [[Skills/s2-arquitetura-tecnica|s2]] para o modelo WASM e execução de contratos
- → [[Skills/s4-ecossistema-fintech|s4]] para contexto de uso dos contratos em DeFi/RWA
- → [[Agentes/near-fintech-agent|near-fintech-agent]] (agente pai)