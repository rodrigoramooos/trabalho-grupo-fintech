# 🧩 s3 — Governança, Regulação e Compliance

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#regulacao` `#MiCA` `#governanca` `#compliance`

---

## Âmbito de Ativação

Ativada quando a questão envolve: governança NEAR, NEAR Foundation, Reference Maintainer, slashing, double signing, Hidden Validators, VRF, Fishermen, fraud proofs, MiCA, SEC, ESMA, Banco de Portugal, classificação jurídica de tokens, compliance em DeFi, KYC/AML, Travel Rule, smart contracts e responsabilidade legal.

---

## Conteúdo Principal

### Governança NEAR

| Componente | Papel |
|---|---|
| NEAR Foundation | Gere ecosystem fund, grants e representação institucional; gere Protocol Treasury (0,5% inflação) |
| Reference Maintainer | Mantém implementação canónica do protocolo — ponto de centralização reconhecido |
| Validadores | Implementam atualizações de protocolo via upgrades de software |

- Governança **off-chain**: sem votação on-chain formal (diferença face a Tezos/Cosmos)

### Regulação por Jurisdição

| Jurisdição | Enquadramento |
|---|---|
| União Europeia | MiCA — Reg. (UE) 2023/1114; token NEAR = "outros criptoativos" |
| Estados Unidos | SEC (Howey Test) + CFTC; ausência de legislação federal abrangente |
| Portugal | Banco de Portugal (CASP); CMVM (instrumentos financeiros) |

### KYC/AML em DeFi
- Protocolos descentralizados sem entidade central responsável → foco regulatório nos pontos de entrada/saída
- **Travel Rule (GAFI):** difícil implementação em DeFi puro

---

## Relações

- → [[Skills/s4-ecossistema-fintech|s4]] para casos de uso DeFi com implicações regulatórias
- → [[Arquitetura/nightshade#Segurança|Segurança NEAR]] para mecanismos técnicos de slashing
- → [[Agentes/near-fintech-agent|near-fintech-agent]] (agente pai)

---

## Limitações

- Não fornece aconselhamento jurídico ou fiscal
- Regulação cripto evolui rapidamente — verificar versões mais recentes