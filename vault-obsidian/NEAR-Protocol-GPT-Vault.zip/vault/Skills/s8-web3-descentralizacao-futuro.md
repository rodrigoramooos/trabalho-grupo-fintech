# 🧩 s8 — Web3, Descentralização e Futuro

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#Web3` `#futuro` `#AI` `#DID` `#CBDC` `#chainabstraction`

---

## Âmbito de Ativação

Ativada quando a questão envolve: evolução Web1→Web2→Web3, NEAR BOS, SSI/DID, convergência AI+blockchain, NEAR AI, agentes autónomos, chain abstraction, CBDCs, integração institucional, críticas ao Web3, privacidade on-chain.

---

## Conteúdo Principal

### Web1 → Web2 → Web3

| Geração | Característica | Poder |
|---|---|---|
| Web1 | Read-only; sites estáticos | Distribuído |
| Web2 | Read-write; plataformas centralizadas | Big Tech |
| Web3 | Read-write-own; protocolos abertos | Utilizadores |

### Identidade Auto-Soberana (SSI/DID)
- **DID (W3C):** identificador controlado pelo utilizador, sem autoridade central
- **Verifiable Credentials:** credenciais assinadas criptograficamente (diplomas, KYC)
- **Zero-Knowledge Proofs:** provar um facto sem revelar os dados (ex: "sou maior de 18" sem revelar data de nascimento)
- **NEAR:** contas `nome.near` como base de identidade + múltiplas chaves com permissões diferenciadas

### Convergência AI + Blockchain

| Problema da AI | Solução Blockchain |
|---|---|
| Opacidade ("black box") | Auditoria on-chain de decisões |
| Centralização | Modelos open-source, inferência descentralizada |
| Propriedade de dados de treino | Tokenização — criadores recebem royalties |
| Identidade de agentes AI | DIDs para agentes autónomos |

### NEAR AI
- Reposicionamento estratégico (2024) como AI-native blockchain
- Agentes AI autónomos com carteiras NEAR — deter fundos, assinar transações, interagir com contratos

### Chain Abstraction
- Utilizador interage via conta NEAR única → sistema gere as blockchains subjacentes
- Implementação via MPC (Multi-Party Computation) para controlar chaves em outras blockchains

### CBDCs e Integração Institucional
- 130+ países a explorar CBDCs — moeda fiduciária digital controlada pelo banco central
- BlackRock, Franklin Templeton: fundos tokenizados on-chain (maioritariamente Ethereum)
- Mercado RWA estimado em $16 triliões até 2030 (BCG)

---

## Críticas ao Web3 — Resumo

| Crítica | Validade | Resposta |
|---|---|---|
| "Blockchain é uma BD pior" | Parcialmente verdade | Válido sem adversário; blockchain adiciona valor quando há desconfiança mútua |
| "Web3 é especulação" | Parcialmente verdade | Especulação financia bootstrap; questão é se utilidade real emerge |
| "Descentralização é ilusão" | Válida e importante | Descentralização é um espectro — medir graus, não aceitar afirmações de marketing |
| "Consome demasiada energia" | Válida para PoW | NEAR usa PoS — consumo negligenciável; carbon neutral desde 2021 |

---

## Relações

- → [[Skills/s4-ecossistema-fintech|s4]] para casos de uso concretos do ecossistema
- → [[Skills/s3-governanca-regulacao|s3]] para implicações regulatórias (CBDCs, MiCA)
- → [[Agentes/near-fintech-agent|near-fintech-agent]] (agente pai)