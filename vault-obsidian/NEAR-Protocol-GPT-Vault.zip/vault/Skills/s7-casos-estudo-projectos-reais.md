# 🧩 s7 — Casos de Estudo e Projetos Reais

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#casos-estudo` `#DeFi` `#ecossistema` `#analise-critica`

---

## Âmbito de Ativação

Ativada quando a questão envolve: projetos reais da NEAR (Aurora, Ref Finance, Meta Pool, Sweat Economy, NEAR Social), métricas de adoção, TVL, casos de sucesso e falha, lições académicas, sustentabilidade de modelos DeFi.

---

## Casos de Estudo

### Ref Finance — DEX nativa NEAR
- AMM com pools estáveis e voláteis; token REF para governança
- Fee: 0,3%/swap → 0,25% para LPs + 0,05% para treasury
- **Lição:** Bootstrap com liquidity mining cria dependência — yields artificiais geram pressão de venda

### Meta Pool — Liquid Staking
- Deposita NEAR → recebe **stNEAR** (líquido, utilizável em DeFi)
- Distribui stake por múltiplos validators → descentralização
- **Lição:** Liquid staking resolve o trade-off staking/liquidez, mas concentração (ex: Lido no ETH) cria risco sistémico

### Sweat Economy — Move-to-Earn
- Lançou com ~13M utilizadores (migrados da app Sweatcoin)
- Token SWEAT gerado por passos; emissão deflacionária progressiva
- **Lição:** Migração Web2→Web3 é mais eficaz que adoção cripto-native; modelos X-to-Earn têm fragilidade estrutural

### NEAR Social — Rede Social On-Chain
- Posts e perfis armazenados no contrato `social.near`
- Dados pertencem ao utilizador — portabilidade real
- **Lição:** Custo de storage cria fricção face ao Web2 gratuito

### Caso Negativo — NEAR Ecosystem Fund ($800M)
- Acelerou construção de infraestrutura mas criou dependência
- Muitos projetos descontinuaram após fim dos incentivos
- **Lição:** Ecosystem funds são eficazes para bootstrap mas criam dependência sem modelo de receita orgânica

---

## Framework de Análise de Projetos Web3

1. **Problema e Solução** — A blockchain é necessária?
2. **Modelo Económico** — O token tem utilidade real? Yields sustentáveis?
3. **Descentralização Real** — Quem controla os contratos? Existe admin key?
4. **Tração e Métricas** — Utilizadores reais vs. bots? TVL orgânico?
5. **Riscos** — Smart contract, regulatório, mercado, team

---

## Relações

- → [[Skills/s4-ecossistema-fintech|s4]] para contexto técnico dos projetos
- → [[Skills/s3-governanca-regulacao|s3]] para riscos regulatórios dos modelos
- → [[Agentes/near-fintech-agent|near-fintech-agent]] (agente pai)

---

## Limitações

- Métricas de TVL e utilizadores são dinâmicas — valores como referência histórica
- Não constitui recomendação de uso ou investimento