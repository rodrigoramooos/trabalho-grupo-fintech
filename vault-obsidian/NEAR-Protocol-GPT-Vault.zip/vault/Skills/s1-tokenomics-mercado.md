# 🧩 s1 — Tokenomics e Mercado

> **Agente:** [[Agentes/near-protocol-agent|near-protocol-agent]]
> **Tags:** `#skill` `#tokenomics` `#mercado` `#DeFi` `#economia`

---

## Âmbito de Ativação

Ativada quando a questão envolve: tokenomics NEAR, staking, inflação, deflação, fee burning, supply, epoch rewards, treasury, governance, análise de preço, correlação com Bitcoin/Ethereum, ciclos de mercado, capitalização, Aurora EVM, Rainbow Bridge, DeFi, NFTs, Web3, identidade digital, RWA, Contract Rewards, gas e armazenamento.

---

## Conteúdo Principal

### Funções do Token NEAR
1. **Pagamento** — gas e armazenamento on-chain
2. **Staking** — participação no consenso (Thresholded PoS)
3. **Governança** — participação em decisões de protocolo

### Política Monetária

| Parâmetro | Valor |
|---|---|
| Inflação anual máxima | 5% |
| Fee burning | 70% das taxas destruídas |
| Protocol Treasury | 0,5% da inflação |
| Contract Rewards | 30% das taxas para o developer |
| Armazenamento | 1 NEAR por 100 KB on-chain |

### Gas vs. Armazenamento
- **Gas:** calculado algoritmicamente pela complexidade da operação; ajuste dinâmico pela taxa de ocupação
- **Armazenamento:** saldo mínimo mantido pelo contrato; 1 NEAR por 100 KB persistidos

### Deflação
Em cenários de alta utilização, o fee burning (70% das taxas) pode superar a emissão → token deflacionário

---

## Relações

- → [[Arquitetura/tokenomics|Tokenomics NEAR]] (nota de arquitetura detalhada)
- → [[s4-ecossistema-fintech|s4]] para casos de uso DeFi e Aurora
- → [[Agentes/near-protocol-agent|near-protocol-agent]] (agente pai)

---

## Limitações

- Não cobre arquitetura técnica (→ [[s2-arquitetura-tecnica|s2]])
- Análise de mercado é académica — não constitui aconselhamento financeiro
- Métricas de preço e capitalização são dinâmicas
