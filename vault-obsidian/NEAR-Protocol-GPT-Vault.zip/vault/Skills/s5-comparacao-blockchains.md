# 🧩 s5 — Comparação de Blockchains

> **Agente:** [[Agentes/near-fintech-agent|near-fintech-agent]]
> **Tags:** `#skill` `#comparacao` `#trilemma` `#L1` `#benchmarking`

---

## Âmbito de Ativação

Ativada quando a questão envolve: comparação entre NEAR e outras blockchains, trilemma da blockchain, escolha de plataforma para dApps, comparação de mecanismos de consenso, throughput/latência/custo, tokenomics comparativos, Nakamoto Coefficient.

---

## Conteúdo Principal

### O Trilemma de Buterin
> Uma blockchain não pode otimizar simultaneamente **Segurança**, **Escalabilidade** e **Descentralização**.

### Comparação de Métricas

| | NEAR | Ethereum | Solana | Avalanche |
|---|---|---|---|---|
| **Consenso** | Doomslug + PoS | Casper FFG + PoS | PoH + Tower BFT | Snowman PoS |
| **Finalidade** | ~2 seg | ~12–15 min | <1 seg | ~2 seg |
| **TPS produção** | ~1–2k | ~12–15 | ~2–4k | ~1–2k |
| **Custo/tx** | ~$0,001 | $3–50+ | ~$0,00025 | ~$0,10–0,50 |
| **EVM** | Sim (Aurora) | Nativa | Não | Sim (C-Chain) |
| **Escalabilidade** | Sharding nativo | L2 Rollups | Vertical | Subnet + DAG |

> ⚠️ TPS teórico NEAR: 100.000+. TPS real muito inferior — sharding completo em desenvolvimento.

### Coeficiente de Nakamoto (aprox.)

| Blockchain | Nakamoto Coefficient |
|---|---|
| Bitcoin | ~3–4 |
| Ethereum | ~3–5 |
| NEAR | ~7–10 |
| Solana | ~19 |

### Matriz de Decisão — Quando Escolher NEAR

| Caso de Uso | NEAR | Ethereum | Solana |
|---|---|---|---|
| DeFi com máxima liquidez | ✗ | ✓✓ | ✓ |
| Alta frequência, baixo custo | ✓ | ✗ | ✓✓ |
| Migração de contratos ETH | ✓ (Aurora) | ✓✓ | ✗ |
| Developer experience | ✓✓ | ✓ | ✓ |

---

## Relações

- → [[Skills/s2-arquitetura-tecnica|s2]] para detalhes técnicos do NEAR
- → [[Skills/s4-ecossistema-fintech|s4]] para comparação ao nível de aplicações DeFi
- → [[Agentes/near-fintech-agent|near-fintech-agent]] (agente pai)