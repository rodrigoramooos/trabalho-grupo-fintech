# 🏠 NEAR Protocol GPT — Vault

> Projeto Final de FinTech | 2025/2026
> Rodrigo Ramos · Bruno Almeida · Rodrigo Pedro
> Orientador: Francisco Pires

---

## Navegação Rápida

### 🤖 Agentes
- [[Agentes/near-protocol-agent|near-protocol-agent]] — Agente Global (arquitetura, tokenomics, consenso)
- [[Agentes/near-fintech-agent|near-fintech-agent]] — Agente Especializado (ecossistema, regulação, Web3)
- [[Agentes/near-critic-agent|near-critic-agent]] — Agente de Autoavaliação Crítica

### 🧩 Skills
| Skill | Âmbito |
|---|---|
| [[Skills/s1-tokenomics-mercado\|s1]] | Tokenomics, mercado, DeFi |
| [[Skills/s2-arquitetura-tecnica\|s2]] | Nightshade, Doomslug, WASM |
| [[Skills/s3-governanca-regulacao\|s3]] | MiCA, SEC, Banco de Portugal, slashing |
| [[Skills/s4-ecossistema-fintech\|s4]] | Aurora, RWA, pagamentos, BOS |
| [[Skills/s5-comparacao-blockchains\|s5]] | Trilemma, benchmarking L1 |
| [[Skills/s6-desenvolvimento-smart-contracts\|s6]] | Rust, NEPs, cross-contract, segurança |
| [[Skills/s7-casos-estudo-projectos-reais\|s7]] | Ref Finance, Meta Pool, Sweat Economy |
| [[Skills/s8-web3-descentralizacao-futuro\|s8]] | Web3, SSI/DID, NEAR AI, CBDCs |

### 🏗️ Arquitetura
- [[Arquitetura/sistema-gpt|Sistema NEAR Protocol GPT]] — Visão geral da arquitetura
- [[Arquitetura/nightshade|Nightshade Sharding]] — Mecanismo técnico central
- [[Arquitetura/tokenomics|Tokenomics NEAR]] — Modelo económico
- [[Arquitetura/ecossistema|Ecossistema e Casos de Uso]] — Aurora, DeFi, RWA

### 📦 Recursos
- [[Recursos/glossario|Glossário]] — 37 termos definidos
- [[Recursos/referencias|Referências Bibliográficas]]
- [[Recursos/materiais-complementares|Materiais Complementares]] — Slides, Vídeo, Podcast

---

## Questão de Investigação

> Em que medida o NEAR Protocol representa uma solução tecnicamente viável e economicamente sustentável para os desafios de escalabilidade, interoperabilidade e adoção das plataformas blockchain no contexto das Tecnologias Financeiras contemporâneas?

---

## Tags do Vault
`#NEAR` `#blockchain` `#FinTech` `#DeFi` `#Web3` `#agentes-IA` `#skills`
