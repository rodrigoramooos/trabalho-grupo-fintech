# 📚 Referências Bibliográficas

> **Tags:** `#referencias` `#fontes`

---

## Fontes Primárias

**NEAR Foundation** (s.d.)
*The NEAR White Paper.*
https://pages.near.org/

**Skidanov, A., & Polosukhin, I.** (2019)
*Nightshade: Near Protocol Sharding Design.*
NEAR Protocol Technical Paper.
https://near.org/papers/nightshade

**Tama, D., & Wicaksana, A.** (2023)
*Performance Evaluation of Decentralized Social Media on Near Protocol Blockchain.*
17th International Conference on Ubiquitous Information Management and Communication (IMCOM). IEEE.
DOI: 10.1109/IMCOM56909.2023.10035654

---

## Regulação

**European Parliament and Council** (2023)
*Regulation (EU) 2023/1114 on Markets in Crypto-Assets (MiCA).*
Official Journal of the European Union.

---

## Literatura Académica

**Buterin, V.** (2021)
*Why sharding is great: Demystifying the technical properties.*
Ethereum Foundation Blog.
https://vitalik.ca/general/2021/04/07/sharding.html

**Nakamoto, S.** (2008)
*Bitcoin: A peer-to-peer electronic cash system.*
https://bitcoin.org/bitcoin.pdf

**Schueffel, P.** (2016)
*Taming the beast: A scientific definition of fintech.*
Journal of Innovation Management, 4(4), 32–54.

**Tapscott, D., & Tapscott, A.** (2016)
*Blockchain revolution: How the technology behind bitcoin is changing money, business, and the world.*
Portfolio/Penguin.

---

## Notas

- Os documentos NEAR (White Paper e Nightshade Paper) têm datas de publicação entre 2019 e s.d. — a tecnologia evoluiu significativamente desde então.
- Para dados de mercado e métricas on-chain atualizados: DeFiLlama · CoinMarketCap · NEAR Explorer
