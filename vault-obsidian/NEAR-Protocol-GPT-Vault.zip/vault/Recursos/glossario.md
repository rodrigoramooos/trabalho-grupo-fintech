# 📖 Glossário

> **Tags:** `#glossario` `#definicoes`
> 37 termos definidos — alinhados com o Relatório Final

---

| Termo | Definição |
|---|---|
| **AMM** | Automated Market Maker — exchange descentralizada com preços determinados algoritmicamente por pools de liquidez |
| **Aurora** | Implementação do EVM como contrato inteligente na NEAR, permitindo execução de contratos Solidity |
| **Blockchain** | Registo distribuído, imutável e criptograficamente seguro de transações, mantido de forma descentralizada |
| **Chain Abstraction** | Camada que permite ao utilizador interagir com múltiplas blockchains através de uma conta única |
| **Chunk** | Parte de bloco produzida em paralelo por validadores de um shard específico na arquitetura Nightshade |
| **Contract Rewards** | Mecanismo NEAR: 30% das taxas geradas por um contrato revertem para o seu developer |
| **DAO** | Decentralised Autonomous Organisation — organização gerida por contratos inteligentes e votação on-chain |
| **DeFi** | Decentralised Finance — serviços financeiros implementados em contratos inteligentes, sem intermediários |
| **DID** | Decentralised Identifier — identificador digital controlado pelo utilizador, sem autoridade central (W3C) |
| **Doomslug** | Algoritmo de finalização de blocos da NEAR, com finalidade determinística em ~2 segundos |
| **Epoch** | Unidade de tempo da NEAR (~12 horas) para recalcular validadores e distribuir recompensas |
| **Fee Burning** | Destruição de 70% das taxas de transação NEAR, criando pressão deflacionária |
| **Fishermen** | Nós leves da NEAR que submetem fraud proofs quando detetam chunks inválidos |
| **Gas** | Custo computacional de operações on-chain; na NEAR calculado algoritmicamente |
| **Hidden Validators** | Validadores NEAR selecionados via VRF — não conhecidos antecipadamente, impedindo ataques adaptativos |
| **Layer 1 (L1)** | Protocolo blockchain base, responsável pelo consenso e armazenamento do estado |
| **Layer 2 (L2)** | Solução de escalabilidade construída sobre L1, processando transações off-chain |
| **Liquid Staking** | Staking com emissão de token líquido representativo (ex: stNEAR da Meta Pool) |
| **MiCA** | Markets in Crypto-Assets Regulation — Reg. (UE) 2023/1114 para criptoativos na União Europeia |
| **NEP** | NEAR Enhancement Proposal — proposta de melhoria ao protocolo ou standards NEAR |
| **NFT** | Non-Fungible Token — token único representando propriedade de ativo digital ou físico |
| **Nightshade** | Arquitetura de sharding dinâmico da NEAR — blockchain lógica única dividida em shards paralelos |
| **Proof-of-Stake (PoS)** | Consenso onde validadores são selecionados pelo stake depositado |
| **Rainbow Bridge** | Ponte bidirecional trustless NEAR ↔ Ethereum via light clients |
| **RWA** | Real World Assets — ativos físicos/financeiros tokenizados: imóveis, obrigações, commodities |
| **Sharding** | Divisão do estado e processamento de uma blockchain em partições paralelas (shards) |
| **Skill** | Módulo Markdown que especializa o comportamento de um agente LLM num sub-domínio específico |
| **Slashing** | Penalização de validadores desonestos com perda parcial ou total do stake |
| **Smart Contract** | Programa autoexecutável armazenado numa blockchain |
| **SSI** | Self-Sovereign Identity — identidade digital auto-soberana controlada pelo utilizador |
| **Stablecoin** | Criptomoeda indexada a ativo de referência estável (ex: USD, EUR) |
| **Thresholded PoS** | Variante PoS da NEAR com limiar dinâmico de stake para maximizar validadores únicos |
| **Trilemma da Blockchain** | Postulado de Buterin: não se pode otimizar simultaneamente segurança, escalabilidade e descentralização |
| **TVL** | Total Value Locked — valor total depositado em protocolos DeFi |
| **VRF** | Verifiable Random Function — função criptográfica que gera aleatoriedade pública e verificável |
| **WASM** | WebAssembly — formato de execução dos contratos NEAR, compilado de Rust ou AssemblyScript |
| **Web3** | Visão da internet baseada em protocolos descentralizados e propriedade de dados pelos utilizadores |
