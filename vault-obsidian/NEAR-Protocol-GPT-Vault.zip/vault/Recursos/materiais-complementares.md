# 🎬 Materiais Complementares

> **Tags:** `#materiais` `#video` `#slides` `#podcast` `#NotebookLM`

---

## Visão Geral

Três materiais de divulgação académica produzidos em complemento ao relatório escrito e ao sistema NEAR Protocol GPT.

---

## 🎥 Vídeo Explicativo

| Parâmetro | Valor |
|---|---|
| Duração | 4–6 minutos |
| Formato | Screencast com narração em voz em off |
| Resolução | Mínimo 1080p, MP4 H.264 |

### Estrutura
1. Abertura — questão de investigação
2. O Problema — trilema da blockchain
3. A Solução NEAR — Nightshade, Doomslug, Hidden Validators
4. Modelo Económico — inflação, fee burning, Contract Rewards
5. Ecossistema FinTech — Aurora, DeFi, RWA
6. Comparação L1 — tabela NEAR vs. concorrentes
7. NEAR Protocol GPT — sistema de agentes
8. Conclusão

---

## 📊 Apresentação de Slides

| Parâmetro | Valor |
|---|---|
| Nº de slides | 14 |
| Duração | 12–15 minutos |
| Formato | Suporte a apresentação oral perante júri |

### Slides-chave
- **Slide 5** — Diagrama do trilemma
- **Slide 6** — Arquitetura Nightshade
- **Slide 10** — Tabela comparativa L1
- **Slide 13** — Diagrama do sistema NEAR Protocol GPT

---

## 🎙️ Episódio de Podcast

| Parâmetro | Valor |
|---|---|
| Duração | 12–15 minutos |
| Formato | Conversa entre Apresentador e Especialista |
| Título | "NEAR Protocol: Blockchain, FinTech e o Futuro da Web3" |
| Exportação | MP3 320kbps ou WAV 44.1kHz |

### Blocos Temáticos
1. NEAR e o Trilema
2. Ecossistema e Casos de Uso FinTech
3. Críticas e Riscos
4. NEAR AI e Futuro

---

## Produção via NotebookLM

Todos os materiais foram produzidos com apoio do NotebookLM, utilizando:
- PDFs de apoio específicos para cada material (guias de estrutura e conteúdo)
- Prompts otimizados para geração de guiões e conteúdo estruturado
- Relatório Final como fonte de conhecimento base

---

## Relações

- → [[Arquitetura/sistema-gpt|Sistema NEAR Protocol GPT]]
- → [[Recursos/referencias|Referências Bibliográficas]]
